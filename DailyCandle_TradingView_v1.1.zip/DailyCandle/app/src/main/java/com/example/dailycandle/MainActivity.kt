package com.example.dailycandle

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.content.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var chart: CandleChartView
    private lateinit var input: EditText
    private lateinit var info: TextView
    private val prefs by lazy { getSharedPreferences("daily_candle", MODE_PRIVATE) }
    private val values = mutableListOf<Double>()
    private val dates = mutableListOf<String>()
    private val fmt = SimpleDateFormat("yyyy/MM/dd", Locale.US)
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(18, 21, 28)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        load()
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(10),dp(8),dp(10),dp(10)) }
        val head = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text="Daily Candle"; textSize=21f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
        head.addView(title, LinearLayout.LayoutParams(0,dp(42),1f))
        val reset = Button(this).apply { text="↺"; textSize=20f; setTextColor(Color.LTGRAY); background=round(panel,dp(10)); setOnClickListener{ chart.resetView() } }
        head.addView(reset, LinearLayout.LayoutParams(dp(50),dp(42)))
        root.addView(head)

        chart = CandleChartView(this, values, dates)
        chart.onSelected = { idx -> updateInfo(idx) }
        root.addView(chart, LinearLayout.LayoutParams(-1,0,1f))

        info = TextView(this).apply { text="اولین عدد را وارد کن"; textSize=12f; setTextColor(Color.LTGRAY); setPadding(dp(8),dp(5),dp(8),dp(5)) }
        root.addView(info, LinearLayout.LayoutParams(-1,dp(28)))

        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(7),0,0) }
        input = EditText(this).apply { hint="عدد امروز"; textSize=17f; setSingleLine(); inputType=2 or 8192; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(130,135,145)); background=round(panel,dp(12)); setPadding(dp(16),0,dp(12),0) }
        row.addView(input, LinearLayout.LayoutParams(0,dp(56),1f))
        val btn = Button(this).apply { text="ثبت"; textSize=15f; setTextColor(Color.WHITE); background=round(Color.rgb(35,150,85),dp(12)); setOnClickListener{addValue()} }
        val bp=LinearLayout.LayoutParams(dp(88),dp(56)); bp.marginStart=dp(8); row.addView(btn,bp)
        root.addView(row)
        val hint=TextView(this).apply { text="Open = عدد روز قبل  •  Close = عدد امروز  •  بدون Shadow  •  دو انگشت = زوم"; textSize=11f; setTextColor(Color.rgb(120,125,135)); setPadding(dp(5),dp(7),dp(5),0) }
        root.addView(hint,LinearLayout.LayoutParams(-1,dp(25)))
        setContentView(root)
        if(values.isNotEmpty()) updateInfo(values.lastIndex)
    }

    private fun addValue(){
        val v=input.text.toString().trim().replace(',','.').toDoubleOrNull() ?: run { input.error="عدد معتبر وارد کن"; return }
        values.add(v); dates.add(fmt.format(Date())); save(); chart.invalidate(); updateInfo(values.lastIndex); input.text.clear()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken,0)
    }
    private fun updateInfo(i:Int){
        if(values.isEmpty()){info.text="اولین عدد را وارد کن";return}
        val open=if(i==0) values[0] else values[i-1]; val close=values[i]; val dir=when{close>open->"صعودی";close<open->"نزولی";else->"بدون تغییر"}
        info.text="روز ${i+1}  •  ${dates.getOrNull(i) ?: ""}  •  O ${fmtNum(open)}  C ${fmtNum(close)}  •  $dir"
    }
    private fun fmtNum(x:Double)=String.format(Locale.US,"%.4f",x).trimEnd('0').trimEnd('.')
    private fun save(){ prefs.edit().putString("values",values.joinToString(",")).putString("dates",dates.joinToString("|")).apply() }
    private fun load(){ prefs.getString("values","")?.takeIf{it.isNotBlank()}?.split(",")?.forEach{it.toDoubleOrNull()?.let(values::add)}; prefs.getString("dates","")?.takeIf{it.isNotBlank()}?.split("|")?.let{dates.addAll(it)} }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).roundToInt()
    private fun round(color:Int,r:Int)=GradientDrawable().apply{setColor(color);cornerRadius=r.toFloat()}
}

class CandleChartView(ctx:Context, private val values:List<Double>, private val dates:List<String>):View(ctx){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var zoom=1f; private var offset=0f; private var lastX=0f; private var lastY=0f; private var mode=0; private var pinchStart=1f; private var selected=-1
    var onSelected:((Int)->Unit)?=null
    init{setBackgroundColor(Color.rgb(13,15,20)); isClickable=true}
    private fun dp(v:Int)=v*resources.displayMetrics.density
    override fun onDraw(c:Canvas){super.onDraw(c); val w=width.toFloat();val h=height.toFloat(); if(values.isEmpty()){p.color=Color.GRAY;p.textSize=16.dp();c.drawText("اولین عدد را وارد کن",w/2-65.dp(),h/2,p);return}
        val minV=values.minOrNull()!!;val maxV=values.maxOrNull()!!;val raw=maxV-minV;val pad=if(raw==0.0) max(abs(maxV)*.02,1.0) else raw*.12;val lo=minV-pad;val hi=maxV+pad;val top=18.dp();val bottom=h-34.dp();val chartH=bottom-top
        p.style=Paint.Style.STROKE;p.strokeWidth=1.dp();p.color=Color.rgb(38,42,50)
        for(i in 0..6){val y=top+chartH*i/6f;c.drawLine(0f,y,w,y,p);val v=hi-(hi-lo)*i/6f;p.style=Paint.Style.FILL;p.color=Color.rgb(130,135,145);p.textSize=10.dp();c.drawText(fmt(v),8.dp(),y-4.dp(),p);p.style=Paint.Style.STROKE;p.color=Color.rgb(38,42,50)}
        val gap=58.dp()*zoom;val bw=max(10.dp(),34.dp()*zoom);val base=22.dp()+offset
        fun y(v:Double)=top+((hi-v)/(hi-lo)*chartH).toFloat()
        val first=max(1,ceil((-base-bw)/gap).toInt());val last=min(values.lastIndex,floor((w-base+bw)/gap).toInt())
        for(i in first..last){if(i<1)continue;val open=values[i-1];val close=values[i];val x=base+i*gap;val yt=y(max(open,close));val yb=y(min(open,close));p.style=Paint.Style.FILL;p.color=if(close>=open)Color.rgb(38,190,90) else Color.rgb(232,74,74);c.drawRect(x-bw/2,yt,x+bw/2,max(yb,yt+2.dp()),p);if(i==selected){p.style=Paint.Style.STROKE;p.strokeWidth=2.dp();p.color=Color.WHITE;c.drawRect(x-bw/2-2.dp(),yt-2.dp(),x+bw/2+2.dp(),yb+2.dp(),p)}}
        p.style=Paint.Style.FILL;p.textSize=9.dp();p.color=Color.rgb(120,125,135);val step=max(1,round(70/zoom).toInt());for(i in first..last step step){val x=base+i*gap;if(x>20.dp()&&x<w-10.dp())c.drawText((i+1).toString(),x-5.dp(),h-10.dp(),p)}
        if(selected>=1&&selected<values.size){val x=base+selected*gap;p.style=Paint.Style.STROKE;p.strokeWidth=1.dp();p.color=Color.rgb(190,195,205);c.drawLine(x,top,x,bottom,p)}
    }
    private fun fmt(v:Double)=String.format(Locale.US,"%.4f",v).trimEnd('0').trimEnd('.')
    fun resetView(){zoom=1f;offset=0f;selected=-1;invalidate()}
    override fun onTouchEvent(e:MotionEvent):Boolean{when(e.actionMasked){MotionEvent.ACTION_DOWN->{lastX=e.x;lastY=e.y;mode=1;return true};MotionEvent.ACTION_POINTER_DOWN->{if(e.pointerCount>=2){mode=2;pinchStart=dist(e);return true}};MotionEvent.ACTION_MOVE->{if(mode==1){offset+=e.x-lastX;lastX=e.x;invalidate()}else if(mode==2&&e.pointerCount>=2){val d=dist(e);if(pinchStart>0){zoom=(zoom*d/pinchStart).coerceIn(.45f,3.5f);pinchStart=d;invalidate()};};return true};MotionEvent.ACTION_UP->{if(mode==1){val gap=58.dp()*zoom;val base=22.dp()+offset;val idx=round((e.x-base)/gap).toInt();if(idx>=1&&idx<values.size){selected=idx;onSelected?.invoke(idx);invalidate()}};mode=0;return true};MotionEvent.ACTION_POINTER_UP->{if(e.pointerCount-1<2)mode=1;return true}};return true}
    private fun dist(e:MotionEvent):Float{if(e.pointerCount<2)return 0f;val dx=e.getX(0)-e.getX(1);val dy=e.getY(0)-e.getY(1);return sqrt(dx*dx+dy*dy)}
}

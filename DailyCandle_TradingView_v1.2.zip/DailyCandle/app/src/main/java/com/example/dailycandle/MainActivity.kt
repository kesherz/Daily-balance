package com.example.dailycandle

import android.app.*
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.content.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var chart: CandleChartView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    private val values = mutableListOf<Double>()
    private val dates = mutableListOf<String>()
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.rgb(9,11,16)); window.setNavigationBarColor(Color.rgb(9,11,16))
        load()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(9,11,16)); setPadding(12,8,12,10) }
        val title = TextView(this).apply { text="Daily Candle"; textSize=20f; setTextColor(Color.WHITE); setPadding(6,4,6,10) }
        root.addView(title, LinearLayout.LayoutParams(-1, WRAP_CONTENT))
        chart = CandleChartView(this, values); root.addView(chart, LinearLayout.LayoutParams(-1,0,1f))
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,10,0,0) }
        input = EditText(this).apply { hint="عدد امروز"; textSize=17f; setSingleLine(); inputType=2 or 8192; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setBackgroundColor(Color.rgb(24,27,34)); setPadding(18,0,12,0) }
        row.addView(input, LinearLayout.LayoutParams(0,58.dp(),1f))
        val btn = Button(this).apply { text="ثبت"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(40,140,70)); setOnClickListener { addValue() } }
        val bp=LinearLayout.LayoutParams(92.dp(),58.dp()); bp.marginStart=8; row.addView(btn,bp)
        root.addView(row)
        val hint=TextView(this).apply { text="Open = عدد روز قبل   •   Close = عدد امروز   •   بدون Shadow"; textSize=12f; setTextColor(Color.GRAY); setPadding(6,8,6,0) }
        root.addView(hint,LinearLayout.LayoutParams(-1,WRAP_CONTENT))
        setContentView(root)
    }
    private fun addValue(){
        val v=input.text.toString().replace(',','.').toDoubleOrNull() ?: run { input.error="یک عدد معتبر وارد کن"; return }
        if(values.isNotEmpty() && v==values.last()){ Toast.makeText(this,"عدد ثبت شد؛ کندل بدون تغییر است",Toast.LENGTH_SHORT).show() }
        values.add(v); dates.add(fmt.format(Date())); save(); chart.invalidate(); input.text.clear();
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken,0)
    }
    private fun save(){ prefs.edit().putString("values",values.joinToString(",")).putString("dates",dates.joinToString(",")).apply() }
    private fun load(){
        prefs.getString("values","")?.takeIf{it.isNotBlank()}?.split(",")?.forEach{it.toDoubleOrNull()?.let(values::add)}
        prefs.getString("dates","")?.takeIf{it.isNotBlank()}?.split(",")?.let{dates.addAll(it)}
    }
    private fun Int.dp()=(this*resources.displayMetrics.density).roundToInt()
}

class CandleChartView(ctx: Context, private val values: List<Double>) : View(ctx) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private var scale=1f; private var offset=0f; private var lastX=0f; private var moving=false
    init { setBackgroundColor(Color.rgb(13,15,20)); isFocusable=true }
    override fun onDraw(c: Canvas){ super.onDraw(c); if(values.isEmpty()) { paint.color=Color.GRAY; paint.textSize=16.dp(); c.drawText("اولین عدد را وارد کن",width/2f-65.dp(),height/2f,paint); return }
        val minV=values.minOrNull()!!; val maxV=values.maxOrNull()!!; val range=max(1e-9,maxV-minV); val pad=range*.12+1e-9; val lo=minV-pad; val hi=maxV+pad
        val top=30.dp().toFloat(); val bot=height-35.dp().toFloat(); val h=bot-top; val baseX=20.dp().toFloat()+offset; val gap=64.dp()*scale; val bodyW=max(12.dp().toFloat(),34.dp()*scale)
        paint.style=Paint.Style.STROKE; paint.strokeWidth=1.dp().toFloat(); paint.color=Color.rgb(42,45,53)
        for(i in 0..5){ val y=top+h*i/5f; c.drawLine(0f,y,width.toFloat(),y,paint); val v=hi-(hi-lo)*i/5f; paint.style=Paint.Style.FILL; paint.color=Color.GRAY; paint.textSize=11.dp(); c.drawText(String.format(Locale.US,"%.2f",v),8f,y-4f,paint); paint.style=Paint.Style.STROKE; paint.color=Color.rgb(42,45,53) }
        fun y(v:Double)=top+(hi-v)/(hi-lo)*h
        for(i in 1 until values.size){ val open=values[i-1]; val close=values[i]; val x=baseX+i*gap; if(x<-bodyW||x>width+bodyW) continue; val yt=y(max(open,close)); val yb=y(min(open,close)); paint.style=Paint.Style.FILL; paint.color=if(close>=open) Color.rgb(38,190,90) else Color.rgb(230,70,70); c.drawRect(x-bodyW/2,yt,x+bodyW/2,max(yb,yt+2f),paint); }
        paint.color=Color.LTGRAY; paint.textSize=10.dp(); paint.style=Paint.Style.FILL; val first=max(1,values.size-8); for(i in first until values.size){ val x=baseX+i*gap; if(x>=0&&x<=width) c.drawText("${i+1}",x-5f, height-12.dp(),paint) }
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean { when(e.actionMasked){ MotionEvent.ACTION_DOWN->{lastX=e.x;moving=true;return true}; MotionEvent.ACTION_MOVE->{if(moving){offset+=e.x-lastX;lastX=e.x;invalidate()};return true}; MotionEvent.ACTION_UP->{moving=false;return true} }; return true }
    override fun onGenericMotionEvent(e: MotionEvent): Boolean { if(e.action==MotionEvent.ACTION_SCROLL){scale=(scale*(1f-e.getAxisValue(MotionEvent.AXIS_VSCROLL)*.08f)).coerceIn(.45f,3f);invalidate();return true};return super.onGenericMotionEvent(e) }
    private fun Int.dp()=(this*resources.displayMetrics.density)
}

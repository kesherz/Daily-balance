package com.example.dailycandle;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private CandleChartView chart;
    private EditText input;
    private final ArrayList<Double> values = new ArrayList<>();
    private final ArrayList<String> dates = new ArrayList<>();
    private SharedPreferences prefs;
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,11,16));
        getWindow().setNavigationBarColor(Color.rgb(9,11,16));
        prefs = getSharedPreferences("data", MODE_PRIVATE);
        load();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9,11,16));
        int p = dp(12);
        root.setPadding(p, dp(8), p, dp(10));

        TextView title = new TextView(this);
        title.setText("Daily Candle"); title.setTextSize(20); title.setTextColor(Color.WHITE);
        title.setPadding(dp(6), dp(4), dp(6), dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        chart = new CandleChartView(this, values);
        root.addView(chart, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);

        input = new EditText(this);
        input.setHint("عدد امروز"); input.setTextSize(17); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        input.setBackgroundColor(Color.rgb(24,27,34)); input.setPadding(dp(18),0,dp(12),0);
        row.addView(input, new LinearLayout.LayoutParams(0, dp(58), 1f));

        Button btn = new Button(this);
        btn.setText("ثبت"); btn.setTextColor(Color.WHITE); btn.setBackgroundColor(Color.rgb(40,140,70));
        btn.setOnClickListener(v -> addValue());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(92), dp(58));
        bp.setMarginStart(dp(8)); row.addView(btn, bp);
        root.addView(row);

        TextView hint = new TextView(this);
        hint.setText("Open = عدد روز قبل   •   Close = عدد امروز   •   بدون Shadow");
        hint.setTextSize(12); hint.setTextColor(Color.GRAY); hint.setPadding(dp(6),dp(8),dp(6),0);
        root.addView(hint, new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }

    private void addValue() {
        String s = input.getText().toString().replace(',', '.');
        double v;
        try { v = Double.parseDouble(s); } catch (Exception e) { input.setError("یک عدد معتبر وارد کن"); return; }
        if (!values.isEmpty() && v == values.get(values.size()-1)) Toast.makeText(this,"عدد ثبت شد؛ کندل بدون تغییر است",Toast.LENGTH_SHORT).show();
        values.add(v); dates.add(fmt.format(new Date())); save(); chart.invalidate(); input.setText("");
        InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(),0);
    }

    private void save() {
        StringBuilder vs=new StringBuilder(), ds=new StringBuilder();
        for(int i=0;i<values.size();i++){ if(i>0){vs.append(',');ds.append(',');} vs.append(values.get(i)); ds.append(dates.get(i)); }
        prefs.edit().putString("values",vs.toString()).putString("dates",ds.toString()).apply();
    }
    private void load() {
        String vs=prefs.getString("values",""); if(!vs.isEmpty()) for(String s:vs.split(",")) try{values.add(Double.parseDouble(s));}catch(Exception ignored){}
        String ds=prefs.getString("dates",""); if(!ds.isEmpty()) for(String s:ds.split(",")) dates.add(s);
    }
    private int dp(int n){ return Math.round(n*getResources().getDisplayMetrics().density); }

    static class CandleChartView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private final List<Double> values;
        private float scale=1f, offset=0f, lastX; private boolean moving;
        CandleChartView(Context c,List<Double> v){ super(c); values=v; setBackgroundColor(Color.rgb(13,15,20)); }
        private float dp(float n){return n*getResources().getDisplayMetrics().density;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            if(values.isEmpty()){paint.setColor(Color.GRAY);paint.setTextSize(dp(16));c.drawText("اولین عدد را وارد کن",getWidth()/2f-dp(65),getHeight()/2f,paint);return;}
            double min=values.get(0),max=values.get(0); for(double v:values){min=Math.min(min,v);max=Math.max(max,v);} double range=Math.max(1e-9,max-min),pad=range*.12+1e-9,lo=min-pad,hi=max+pad;
            float top=dp(30),bot=getHeight()-dp(35),h=bot-top,baseX=dp(20)+offset,gap=dp(64)*scale,bodyW=Math.max(dp(12),dp(34)*scale);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(Color.rgb(42,45,53));
            for(int i=0;i<=5;i++){float y=top+h*i/5f;c.drawLine(0,y,getWidth(),y,paint);double pv=hi-(hi-lo)*i/5.0;paint.setStyle(Paint.Style.FILL);paint.setColor(Color.GRAY);paint.setTextSize(dp(11));c.drawText(String.format(Locale.US,"%.2f",pv),dp(8),y-dp(4),paint);paint.setStyle(Paint.Style.STROKE);paint.setColor(Color.rgb(42,45,53));}
            for(int i=1;i<values.size();i++){double open=values.get(i-1),close=values.get(i);float x=baseX+i*gap; if(x<-bodyW||x>getWidth()+bodyW)continue;float yt=(float)(top+(hi-Math.max(open,close))/(hi-lo)*h),yb=(float)(top+(hi-Math.min(open,close))/(hi-lo)*h);paint.setStyle(Paint.Style.FILL);paint.setColor(close>=open?Color.rgb(38,190,90):Color.rgb(230,70,70));c.drawRect(x-bodyW/2,yt,x+bodyW/2,Math.max(yb,yt+dp(2)),paint);}
            paint.setColor(Color.LTGRAY);paint.setTextSize(dp(10));paint.setStyle(Paint.Style.FILL);int first=Math.max(1,values.size()-8);for(int i=first;i<values.size();i++){float x=baseX+i*gap;if(x>=0&&x<=getWidth())c.drawText(String.valueOf(i+1),x-dp(5),getHeight()-dp(12),paint);}
        }
        @Override public boolean onTouchEvent(MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:lastX=e.getX();moving=true;return true;case MotionEvent.ACTION_MOVE:if(moving){offset+=e.getX()-lastX;lastX=e.getX();invalidate();}return true;case MotionEvent.ACTION_UP:moving=false;return true;}return true;}
    }
}
